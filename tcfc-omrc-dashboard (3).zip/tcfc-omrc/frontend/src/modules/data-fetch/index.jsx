import { useState, useCallback, useEffect } from "react";
import { Download, Trash2, RefreshCw } from "lucide-react";
import { api } from "../../api/client.js";
import { useAsync } from "../../lib/useAsync.js";
import { ModuleHeader, Card, Stat, Loader, ErrorState } from "../../components/ui.jsx";
import DataTable from "../../components/DataTable.jsx";
import MultiSelect from "../../components/MultiSelect.jsx";

export const meta = {
  id: "data-fetch",
  title: "Data Fetch",
  description: "Pull EPE / BRV S3 data into reusable datasets.",
  icon: "boxes",
  path: "/data-fetch",
  order: 1,
};

const TRADE_COLS = [
  { key: "trade_id", label: "Trade ID", mono: true },
  { key: "trade_date", label: "Date", mono: true },
  { key: "product_type", label: "Product", mono: true },
  { key: "legal_entity", label: "Legal Entity", mono: true },
  { key: "source_system", label: "Source", mono: true },
  { key: "currency", label: "Ccy", mono: true },
  { key: "booked_price", label: "Booked", align: "right", mono: true },
  { key: "reference_price", label: "Reference", align: "right", mono: true },
];
const EXC_COLS = [
  { key: "exception_id", label: "Exception ID", mono: true },
  { key: "trade_id", label: "Trade ID", mono: true },
  { key: "raised_date", label: "Raised", mono: true },
  { key: "product_type", label: "Product", mono: true },
  { key: "legal_entity", label: "Legal Entity", mono: true },
  { key: "source_system", label: "Source", mono: true },
  { key: "deviation", label: "Deviation", align: "right", mono: true },
  { key: "status", label: "Status" },
];

function downloadCsv(rows, cols, name) {
  if (!rows?.length) return;
  const keys = cols.map((c) => c.key);
  const csv = [keys.join(","), ...rows.map((r) => keys.map((k) => r[k]).join(","))].join("\n");
  const url = URL.createObjectURL(new Blob([csv], { type: "text/csv" }));
  const a = document.createElement("a");
  a.href = url; a.download = name; a.click();
  URL.revokeObjectURL(url);
}

export default function DataFetch() {
  const cfg = useAsync(useCallback(() => api.module("data-fetch", "/filters"), []), []);
  const dsList = useAsync(useCallback(() => api.module("data-fetch", "/datasets"), []), []);

  const [tab, setTab] = useState("trades");
  const [productType, setProductType] = useState("");
  const [legalEntities, setLegalEntities] = useState([]);
  const [sourceSystems, setSourceSystems] = useState([]);
  const [startDate, setStartDate] = useState("2024-01-01");
  const [endDate, setEndDate] = useState(new Date().toISOString().slice(0, 10));

  useEffect(() => {
    if (cfg.data && !productType) {
      setProductType(cfg.data.product_types[0]);
      setLegalEntities([cfg.data.legal_entities[0]]);
      setSourceSystems([cfg.data.source_systems[0]]);
    }
  }, [cfg.data, productType]);

  const [result, setResult] = useState(null);
  const [fetching, setFetching] = useState(false);
  const [fetchErr, setFetchErr] = useState(null);

  async function runFetch() {
    setFetching(true); setFetchErr(null);
    try {
      const body = {
        product_type: productType, legal_entities: legalEntities,
        source_systems: sourceSystems, start_date: startDate, end_date: endDate,
      };
      const path = tab === "trades" ? "/trades" : "/exceptions";
      const data = await api.module("data-fetch", path, undefined, {
        method: "POST", body: JSON.stringify(body),
      });
      setResult(data);
      dsList.reload();
    } catch (e) {
      setFetchErr(e); setResult(null);
    } finally {
      setFetching(false);
    }
  }

  async function removeDataset(id) {
    await api.module("data-fetch", `/datasets/${id}`, undefined, { method: "DELETE" });
    dsList.reload();
  }

  const cols = tab === "trades" ? TRADE_COLS : EXC_COLS;
  const rowKey = tab === "trades" ? "trade_id" : "exception_id";
  const datasets = dsList.data?.datasets || [];

  return (
    <>
      <ModuleHeader
        title="Data Fetch"
        description="Pull from BRV S3 (trades) or EPE (exceptions). Each pull is cached as a dataset the other modules can run on."
      />

      {cfg.loading && <Loader label="Loading filter options…" />}
      {cfg.error && <ErrorState error={cfg.error} />}

      {cfg.data && (
        <>
          <div className="tabs" style={{ marginBottom: 16 }}>
            <button className={`tab ${tab === "trades" ? "active" : ""}`} onClick={() => setTab("trades")}>BRV S3 — Trade Data</button>
            <button className={`tab ${tab === "exceptions" ? "active" : ""}`} onClick={() => setTab("exceptions")}>EPE — Exception Data</button>
          </div>

          <Card title="Filter options">
            <div className="filter-grid">
              <label className="control">
                <span>Product Type</span>
                <select value={productType} onChange={(e) => setProductType(e.target.value)}>
                  {cfg.data.product_types.map((p) => <option key={p} value={p}>{p}</option>)}
                </select>
              </label>
              <MultiSelect label="Legal Entity(s)" options={cfg.data.legal_entities} selected={legalEntities} onChange={setLegalEntities} />
              <MultiSelect label="Source System(s)" options={cfg.data.source_systems} selected={sourceSystems} onChange={setSourceSystems} />
              <label className="control"><span>Start Date</span>
                <input type="date" value={startDate} onChange={(e) => setStartDate(e.target.value)} /></label>
              <label className="control"><span>End Date</span>
                <input type="date" value={endDate} onChange={(e) => setEndDate(e.target.value)} /></label>
              <div className="control" style={{ justifyContent: "flex-end" }}>
                <button className="btn" onClick={runFetch} disabled={fetching}>
                  {fetching ? "Fetching…" : tab === "trades" ? "Fetch trades" : "Fetch exceptions"}
                </button>
              </div>
            </div>
          </Card>

          {fetching && <Loader label="Querying upstream…" />}
          {fetchErr && <ErrorState error={fetchErr} />}

          {result && !fetching && (
            <>
              <div className="stat-grid">
                <Stat label="Dataset stored" value={result.dataset.row_count + " rows"} sub={result.dataset.id} status="pass" />
                <Stat label="Source" value={result.dataset.source} />
                <Stat label="Product" value={result.dataset.product_type} />
                <Stat label="Range" value={`${result.dataset.start_date} → ${result.dataset.end_date}`} />
              </div>
              <Card title={`Preview — ${result.preview.length} of ${result.dataset.row_count} rows`}>
                <div style={{ display: "flex", justifyContent: "flex-end", marginBottom: 10 }}>
                  <button className="btn btn--ghost" onClick={() => downloadCsv(result.preview, cols, `${result.dataset.source}_${result.dataset.id}.csv`)}>
                    <Download size={14} style={{ marginRight: 6, verticalAlign: "-2px" }} /> Download CSV
                  </button>
                </div>
                {result.preview.length === 0
                  ? <div className="empty"><div className="empty-title">No rows for this filter set.</div></div>
                  : <DataTable columns={cols} rows={result.preview} rowKey={rowKey} />}
              </Card>
            </>
          )}

          <Card title={
            <span style={{ display: "flex", alignItems: "center", gap: 8 }}>
              Loaded datasets
              <button className="icon-btn" onClick={dsList.reload} title="Refresh"><RefreshCw size={13} /></button>
            </span>
          }>
            {datasets.length === 0 ? (
              <div className="empty"><div className="empty-hint">Nothing cached yet. Fetch above to create a dataset.</div></div>
            ) : (
              <div className="ds-list">
                {datasets.map((d) => (
                  <div key={d.id} className="ds-row">
                    <span className={`badge badge--${d.source === "EPE" ? "watch" : "pass"}`}>{d.source}</span>
                    <span className="ds-label">{d.label}</span>
                    <span className="mono ds-count">{d.row_count} rows</span>
                    <span className="mono ds-id">{d.id}</span>
                    <button className="icon-btn" onClick={() => removeDataset(d.id)} title="Delete"><Trash2 size={14} /></button>
                  </div>
                ))}
              </div>
            )}
          </Card>
        </>
      )}
    </>
  );
}
