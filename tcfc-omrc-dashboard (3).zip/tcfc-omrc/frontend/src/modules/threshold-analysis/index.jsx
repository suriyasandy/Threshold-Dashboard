import { useState, useCallback, useEffect } from "react";
import {
  BarChart, Bar, LineChart, Line, XAxis, YAxis, Tooltip, Legend,
  ResponsiveContainer, Cell, CartesianGrid,
} from "recharts";
import { api } from "../../api/client.js";
import { useAsync } from "../../lib/useAsync.js";
import { ModuleHeader, Card, Stat, Loader, ErrorState, StatusBadge } from "../../components/ui.jsx";
import DataTable from "../../components/DataTable.jsx";
import DatasetSelector from "../../components/DatasetSelector.jsx";
import { breachStatus } from "../../lib/format.js";

export const meta = {
  id: "threshold-analysis",
  title: "Threshold Analysis",
  description: "Calibrate & backtest thresholds on a fetched trade dataset.",
  icon: "sliders",
  path: "/threshold-analysis",
  order: 2,
};

const STATUS_COLOR = { pass: "#1F8A4C", watch: "#C9821A", breach: "#C0392B" };
const fv = (v, unit, d = 3) => v == null ? "—" : `${Number(v).toFixed(d)}${unit === "%" ? "%" : " " + unit}`;
const floorMax = (u) => (u === "%" ? 1 : u === "bps" ? 10 : 30);
const floorStep = (u) => (u === "%" ? 0.05 : u === "bps" ? 0.25 : 1);
const floorDefault = (u) => (u === "%" ? 0.1 : u === "bps" ? 0.5 : 1);

export default function ThresholdAnalysis() {
  const tds = useAsync(useCallback(() => api.module("threshold-analysis", "/trade-datasets"), []), []);
  const eds = useAsync(useCallback(() => api.module("data-fetch", "/datasets", { source: "EPE" }), []), []);
  const [datasetId, setDatasetId] = useState("");
  const [tab, setTab] = useState("calibration");

  const datasets = tds.data?.datasets || [];
  const selected = datasets.find((d) => d.id === datasetId);

  useEffect(() => {
    if (datasets.length && !datasetId) setDatasetId(datasets[0].id);
  }, [datasets, datasetId]);

  return (
    <>
      <ModuleHeader
        title="Threshold Analysis"
        description="Runs on a BRV S3 trade dataset pulled in Data Fetch. Metric (% / bps / pips) follows the dataset's product type."
      />
      {tds.loading && <Loader label="Loading datasets…" />}
      {tds.error && <ErrorState error={tds.error} />}

      {tds.data && (
        <>
          <div className="toolbar">
            <DatasetSelector
              label="Trade dataset (BRV S3)"
              datasets={datasets}
              value={datasetId}
              onChange={setDatasetId}
              emptyHint="Pull a BRV S3 trade dataset in Data Fetch first."
            />
            {selected && (
              <div className="tabs">
                <button className={`tab ${tab === "calibration" ? "active" : ""}`} onClick={() => setTab("calibration")}>Calibration</button>
                <button className={`tab ${tab === "backtest" ? "active" : ""}`} onClick={() => setTab("backtest")}>Backtesting</button>
              </div>
            )}
          </div>

          {selected && tab === "calibration" && <Calibration ds={selected} />}
          {selected && tab === "backtest" && <Backtest ds={selected} epeDatasets={eds.data?.datasets || []} />}
        </>
      )}
    </>
  );
}

function Calibration({ ds }) {
  const unit = ds.unit;
  const [k, setK] = useState(4);
  const [floor, setFloor] = useState(floorDefault(unit));
  useEffect(() => { setFloor(floorDefault(ds.unit)); }, [ds.id, ds.unit]);

  const load = useCallback(
    () => api.module("threshold-analysis", "/calibrate", undefined,
      { method: "POST", body: JSON.stringify({ dataset_id: ds.id, k, floor }) }),
    [ds.id, k, floor]
  );
  const { loading, data, error, reload } = useAsync(load, [ds.id, k, floor]);
  const buckets = data?.buckets || [];
  const chartData = buckets.map((b) => ({ name: String(b.bucket), value: b.recommended_threshold, status: breachStatus(b.breach_rate_pct) }));

  const columns = [
    { key: "bucket", label: "Bucket", mono: true },
    { key: "currency", label: "Ccy", mono: true },
    { key: "sample_size", label: "n", align: "right", mono: true },
    { key: "median_dev", label: "Median", align: "right", mono: true, render: (v) => fv(v, unit) },
    { key: "mad", label: "MAD", align: "right", mono: true, render: (v) => Number(v).toFixed(3) },
    { key: "recommended_threshold", label: "Threshold", align: "right", mono: true, render: (v) => <strong>{fv(v, unit)}</strong> },
    { key: "breach_rate_pct", label: "Breach rate", align: "right", mono: true,
      render: (v) => <span className="cell-status">{Number(v).toFixed(1)}% <StatusBadge status={breachStatus(v)} /></span> },
  ];

  return (
    <>
      <Card title="Calibration parameters">
        <div className="controls">
          <label className="control"><span>MAD multiplier (k): <strong className="mono">{k.toFixed(1)}</strong></span>
            <input type="range" min="1" max="8" step="0.5" value={k} onChange={(e) => setK(Number(e.target.value))} /></label>
          <label className="control"><span>Floor: <strong className="mono">{fv(floor, unit, 2)}</strong></span>
            <input type="range" min="0" max={floorMax(unit)} step={floorStep(unit)} value={floor} onChange={(e) => setFloor(Number(e.target.value))} /></label>
          <button className="btn" onClick={reload} style={{ alignSelf: "flex-end" }}>Refresh</button>
        </div>
      </Card>
      {loading && <Loader />}
      {error && <ErrorState error={error} />}
      {data && (
        <>
          <Card title={`Recommended thresholds — ${data.trade_count} trades · ${data.product_type} · unit ${unit}`}>
            <div style={{ width: "100%", height: 240 }}>
              <ResponsiveContainer>
                <BarChart data={chartData} margin={{ top: 8, right: 8, bottom: 8, left: 8 }}>
                  <XAxis dataKey="name" tick={{ fontSize: 11 }} /><YAxis tick={{ fontSize: 11 }} />
                  <Tooltip formatter={(v) => [fv(v, unit), "Threshold"]} contentStyle={{ fontSize: 12 }} />
                  <Bar dataKey="value" radius={[3, 3, 0, 0]}>{chartData.map((d, i) => <Cell key={i} fill={STATUS_COLOR[d.status]} />)}</Bar>
                </BarChart>
              </ResponsiveContainer>
            </div>
          </Card>
          <Card><DataTable columns={columns} rows={buckets} rowKey="bucket" /></Card>
        </>
      )}
    </>
  );
}

function Backtest({ ds, epeDatasets }) {
  const unit = ds.unit;
  const [k, setK] = useState(4);
  const [floor, setFloor] = useState(floorDefault(unit));
  const [epeId, setEpeId] = useState("");
  useEffect(() => { setFloor(floorDefault(ds.unit)); }, [ds.id, ds.unit]);

  const load = useCallback(
    () => api.module("threshold-analysis", "/backtest", undefined,
      { method: "POST", body: JSON.stringify({ dataset_id: ds.id, epe_dataset_id: epeId || null, k, floor }) }),
    [ds.id, epeId, k, floor]
  );
  const { loading, data, error, reload } = useAsync(load, [ds.id, epeId, k, floor]);

  return (
    <>
      <Card title="Backtest parameters">
        <div className="controls controls--row">
          <label className="control"><span>Candidate k: <strong className="mono">{k.toFixed(1)}</strong></span>
            <input type="range" min="1" max="8" step="0.5" value={k} onChange={(e) => setK(Number(e.target.value))} /></label>
          <label className="control" style={{ minWidth: 260 }}>
            <span>Ground truth (EPE dataset)</span>
            <select value={epeId} onChange={(e) => setEpeId(e.target.value)}>
              <option value="">None (flag volume only)</option>
              {epeDatasets.map((d) => <option key={d.id} value={d.id}>{d.label}</option>)}
            </select>
          </label>
          <button className="btn" onClick={reload}>Re-run</button>
        </div>
      </Card>
      {loading && <Loader label="Replaying dataset…" />}
      {error && <ErrorState error={error} />}
      {data && <BacktestResults data={data} />}
    </>
  );
}

function BacktestResults({ data }) {
  const a = data.accuracy, d = data.delta;
  const dCls = d.delta > 0 ? "delta-pos" : d.delta < 0 ? "delta-neg" : "";
  const dSign = d.delta > 0 ? "+" : "";
  const cols = [
    { key: "bucket", label: "Bucket", mono: true },
    { key: "n", label: "n", align: "right", mono: true },
    { key: "tp", label: "TP", align: "right", mono: true },
    { key: "fp", label: "FP", align: "right", mono: true },
    { key: "fn", label: "FN", align: "right", mono: true },
    { key: "precision", label: "Precision", align: "right", mono: true, render: (v) => v.toFixed(2) },
    { key: "recall", label: "Recall", align: "right", mono: true, render: (v) => v.toFixed(2) },
    { key: "f1", label: "F1", align: "right", mono: true, render: (v) => v.toFixed(2) },
  ];
  return (
    <>
      <div className="stat-grid">
        <Stat label="Candidate flags" value={d.candidate_total} sub={`k vs baseline k=${d.baseline_k}`} />
        <Stat label="Baseline flags" value={d.baseline_total} />
        <Stat label="Delta" value={<span className={dCls}>{dSign}{d.delta}</span>} sub={d.delta < 0 ? "fewer alerts" : d.delta > 0 ? "more alerts" : "no change"} />
        <Stat label="Confirmed off-market" value={a.confirmed_total} sub={data.has_ground_truth ? "from EPE dataset" : "no EPE selected"} />
      </div>

      <Card title="Flag volume over time — candidate vs baseline">
        <div style={{ width: "100%", height: 260 }}>
          <ResponsiveContainer>
            <LineChart data={data.series} margin={{ top: 8, right: 12, bottom: 8, left: 0 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="#eef1f4" />
              <XAxis dataKey="date" tick={{ fontSize: 10 }} /><YAxis tick={{ fontSize: 11 }} allowDecimals={false} />
              <Tooltip contentStyle={{ fontSize: 12 }} /><Legend wrapperStyle={{ fontSize: 12 }} />
              <Line type="monotone" dataKey="candidate_flags" name="Candidate" stroke="#0E7C7B" strokeWidth={2} dot={false} />
              <Line type="monotone" dataKey="baseline_flags" name="Baseline" stroke="#C9821A" strokeWidth={2} strokeDasharray="5 4" dot={false} />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </Card>

      {data.has_ground_truth ? (
        <>
          <div className="stat-grid">
            <Stat label="Precision" value={a.precision.toFixed(2)} status={a.precision >= 0.8 ? "pass" : a.precision >= 0.5 ? "watch" : "breach"} />
            <Stat label="Recall" value={a.recall.toFixed(2)} status={a.recall >= 0.8 ? "pass" : a.recall >= 0.5 ? "watch" : "breach"} />
            <Stat label="F1 score" value={a.f1.toFixed(2)} />
            <Stat label="Missed (FN)" value={a.fn} status={a.fn === 0 ? "pass" : "breach"} />
          </div>
          <Card title="Confusion — candidate vs confirmed off-market">
            <div className="confusion">
              <div className="cm-cell cm-tp"><span className="mono">{a.tp}</span><small>True positive</small></div>
              <div className="cm-cell cm-fp"><span className="mono">{a.fp}</span><small>False positive</small></div>
              <div className="cm-cell cm-fn"><span className="mono">{a.fn}</span><small>False negative</small></div>
              <div className="cm-cell cm-tn"><span className="mono">{a.tn}</span><small>True negative</small></div>
            </div>
          </Card>
        </>
      ) : (
        <Card><div className="empty"><div className="empty-title">Select an EPE dataset to score precision / recall.</div>
          <div className="empty-hint">Without ground truth, only flag volume is shown.</div></div></Card>
      )}

      <Card title="Per-bucket accuracy"><DataTable columns={cols} rows={data.per_bucket} rowKey="bucket" /></Card>
    </>
  );
}
