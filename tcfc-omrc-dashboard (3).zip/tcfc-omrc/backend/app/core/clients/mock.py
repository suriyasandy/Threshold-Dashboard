"""Synthetic data, asset-class aware. Deterministic per (asset_class, date).

Trades carry a hidden `confirmed_off_market` label so the backtester can
compute real precision/recall. In live mode that label comes from joining BRV
trades to EPE exceptions with a confirmed status — never from BRV itself.
"""
from __future__ import annotations

import random
from datetime import date, timedelta
from typing import Dict, List

from app.core.asset_classes import ASSET_CLASSES

DESKS = ["Flow", "Structured", "EM", "Treasury"]
TRADERS = ["TRD_014", "TRD_022", "TRD_031", "TRD_045", "TRD_058"]


def _rng(seed: str) -> random.Random:
    return random.Random(seed)


def _booked_value(rnd: random.Random, ref: float, vol: float):
    """Return (booked_value, is_off_market). ~5% are genuinely off-market with
    a large move; a small share of normal trades also breach (-> false positives)
    and some off-market moves are subtle (-> false negatives)."""
    roll = rnd.random()
    if roll < 0.05:  # genuinely off-market
        move = rnd.uniform(4, 12) * vol * (1 if rnd.random() < 0.5 else -1)
        # ~20% of these are subtle (will be missed by a tight threshold)
        if rnd.random() < 0.2:
            move *= 0.35
        return ref + move, True
    move = rnd.gauss(0, vol)
    return ref + move, False


def mock_trades(as_of: str, ac_code: str, n: int = 60) -> List[Dict]:
    ac = ASSET_CLASSES[ac_code]
    rnd = _rng(f"{ac_code}-{as_of}")
    rows: List[Dict] = []
    for i in range(n):
        b = rnd.choice(ac["buckets"])
        booked, off = _booked_value(rnd, b["ref"], b["vol"])
        digits = 4 if ac["metric"] != "pct" else 4
        rows.append(
            {
                "trade_id": f"{ac_code[:3]}{as_of.replace('-', '')}{i:04d}",
                "asset_class": ac_code,
                "product_code": b["code"],
                "product_name": b["name"],
                "currency": b["ccy"],
                "desk": rnd.choice(DESKS),
                "trader_id": rnd.choice(TRADERS),
                "notional": rnd.choice([1, 2, 5, 10, 25]) * 1_000_000,
                "booked_value": round(booked, digits),
                "reference_value": round(b["ref"], digits),
                "trade_date": as_of,
                "confirmed_off_market": off,
            }
        )
    return rows


def mock_trade_window(ac_code: str, days: int, as_of: str = "") -> Dict[str, List[Dict]]:
    end = date.fromisoformat(as_of) if as_of else date.today()
    out: Dict[str, List[Dict]] = {}
    for i in range(days):
        d = (end - timedelta(days=i)).isoformat()
        out[d] = mock_trades(d, ac_code)
    return out


def mock_exceptions(as_of: str, n: int = 64) -> List[Dict]:
    """Exception population from EPE (asset-class mixed)."""
    rnd = _rng(f"exc-{as_of}")
    statuses = ["OPEN", "UNDER_REVIEW", "APPROVED", "ESCALATED", "CLOSED"]
    reasons = [
        "Price deviation > threshold",
        "Stale reference price",
        "Manual override flag",
        "Off-market rate suspected",
        "Counterparty mismatch",
    ]
    ac_codes = list(ASSET_CLASSES.keys())
    rows: List[Dict] = []
    for i in range(n):
        ac_code = rnd.choice(ac_codes)
        b = rnd.choice(ASSET_CLASSES[ac_code]["buckets"])
        rows.append(
            {
                "exception_id": f"EPE{as_of.replace('-', '')}{i:04d}",
                "trade_id": f"{ac_code[:3]}{as_of.replace('-', '')}{rnd.randint(0, 59):04d}",
                "asset_class": ac_code,
                "product_code": b["code"],
                "product_name": b["name"],
                "currency": b["ccy"],
                "desk": rnd.choice(DESKS),
                "deviation": round(abs(rnd.gauss(0, 1.4)) + 0.3, 3),
                "status": rnd.choice(statuses),
                "reason": rnd.choice(reasons),
                "raised_date": as_of,
                "ageing_days": rnd.randint(0, 21),
            }
        )
    return rows


# ----------------------------------------------- Data Fetch module records
# Raw, filterable rows carrying legal_entity / source_system dimensions, used
# by the Data Fetch module (distinct from the calibration buckets above).
from datetime import date as _date, timedelta as _td  # noqa: E402

_CCY_BY_LE = {
    "HBEU": "EUR", "HBAP": "USD", "HBUS": "USD", "HBFR": "EUR", "HBUK": "GBP",
    "HBIE": "EUR", "HBSG": "SGD", "HBME": "USD", "HBAU": "AUD", "HBJP": "JPY",
}


def _date_range(start: str, end: str):
    s = _date.fromisoformat(start)
    e = _date.fromisoformat(end)
    days = (e - s).days
    return [(s + _td(days=i)).isoformat() for i in range(max(0, days) + 1)]


def _apply_common(rnd, les, sss):
    le = rnd.choice(les) if les else "HBEU"
    ss = rnd.choice(sss) if sss else "FLEXRATE"
    return le, ss, _CCY_BY_LE.get(le, "USD")


def mock_trade_records(product_type, legal_entities, source_systems,
                       start_date, end_date, per_day=6):
    rnd = _rng(f"trd-{product_type}-{start_date}-{end_date}")
    dates = _date_range(start_date, end_date)
    rows = []
    i = 0
    for d in dates:
        for _ in range(per_day):
            le, ss, ccy = _apply_common(rnd, legal_entities, source_systems)
            ref = round(rnd.uniform(88, 112), 4)
            booked = round(ref * (1 + rnd.gauss(0, 0.4) / 100), 4)
            rows.append({
                "trade_id": f"BRV{d.replace('-', '')}{i:05d}",
                "trade_date": d,
                "product_type": product_type,
                "legal_entity": le,
                "source_system": ss,
                "currency": ccy,
                "counterparty": f"CPTY_{rnd.randint(100, 999)}",
                "notional": rnd.choice([1, 2, 5, 10, 25]) * 1_000_000,
                "booked_price": booked,
                "reference_price": ref,
                "trader_id": rnd.choice(TRADERS),
            })
            i += 1
    return rows


def mock_exception_records(product_type, legal_entities, source_systems,
                           start_date, end_date, per_day=3):
    rnd = _rng(f"exc-{product_type}-{start_date}-{end_date}")
    statuses = ["OPEN", "UNDER_REVIEW", "APPROVED", "ESCALATED", "CLOSED"]
    reasons = [
        "Price deviation > threshold", "Stale reference price",
        "Manual override flag", "Off-market rate suspected", "Counterparty mismatch",
    ]
    dates = _date_range(start_date, end_date)
    rows = []
    i = 0
    for d in dates:
        for _ in range(per_day):
            le, ss, ccy = _apply_common(rnd, legal_entities, source_systems)
            rows.append({
                "exception_id": f"EPE{d.replace('-', '')}{i:05d}",
                "trade_id": f"BRV{d.replace('-', '')}{rnd.randint(0, 999):05d}",
                "raised_date": d,
                "product_type": product_type,
                "legal_entity": le,
                "source_system": ss,
                "currency": ccy,
                "deviation": round(abs(rnd.gauss(0, 1.4)) + 0.3, 3),
                "status": rnd.choice(statuses),
                "reason": rnd.choice(reasons),
                "ageing_days": rnd.randint(0, 21),
            })
            i += 1
    return rows
