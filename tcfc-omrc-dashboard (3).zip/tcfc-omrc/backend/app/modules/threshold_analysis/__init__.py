"""Threshold Analysis plugin — runs on datasets pulled via Data Fetch."""
from __future__ import annotations

from typing import Optional

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel, Field

from app.core import store
from app.core.column_map import CONFIRMED_STATUSES, normalize_exceptions, normalize_trades
from app.core.metrics import FLOOR_DEFAULT, K_DEFAULT, UNIT, metric_for
from app.modules.threshold_analysis.service import backtest, calibrate

META = {
    "id": "threshold-analysis",
    "name": "Threshold Analysis",
    "description": "Calibrate and backtest off-market thresholds on a fetched trade dataset.",
    "icon": "sliders",
}

router = APIRouter()


def _trade_dataset(dataset_id: str):
    meta = store.get_meta(dataset_id)
    rows = store.get_rows(dataset_id)
    if meta is None or rows is None:
        raise HTTPException(404, "Dataset not found")
    if meta.source != "BRV_S3":
        raise HTTPException(400, "Threshold Analysis needs a BRV S3 trade dataset")
    return meta, normalize_trades(rows)


class CalibrateBody(BaseModel):
    dataset_id: str
    k: Optional[float] = None
    floor: Optional[float] = None


class BacktestBody(BaseModel):
    dataset_id: str                    # BRV S3 trades
    epe_dataset_id: Optional[str] = None  # EPE exceptions for ground truth
    k: Optional[float] = None
    floor: Optional[float] = None
    baseline_k: float = 6.0


@router.get("/trade-datasets")
async def trade_datasets():
    metas = store.list_datasets("BRV_S3")
    return {
        "datasets": [
            {"id": m.id, "label": m.label, "product_type": m.product_type,
             "metric": metric_for(m.product_type), "unit": UNIT[metric_for(m.product_type)],
             "row_count": m.row_count, "start_date": m.start_date, "end_date": m.end_date}
            for m in metas
        ]
    }


@router.post("/calibrate")
async def run_calibrate(body: CalibrateBody):
    meta, rows = _trade_dataset(body.dataset_id)
    metric = metric_for(meta.product_type)
    k = K_DEFAULT[metric] if body.k is None else body.k
    floor = FLOOR_DEFAULT[metric] if body.floor is None else body.floor
    buckets = calibrate(rows, meta.product_type, k=k, floor=floor)
    return {
        "dataset_id": meta.id, "product_type": meta.product_type,
        "metric": metric, "unit": UNIT[metric], "k": k, "floor": floor,
        "trade_count": len(rows), "buckets": buckets,
    }


@router.post("/backtest")
async def run_backtest(body: BacktestBody):
    meta, rows = _trade_dataset(body.dataset_id)
    metric = metric_for(meta.product_type)
    k = K_DEFAULT[metric] if body.k is None else body.k
    floor = FLOOR_DEFAULT[metric] if body.floor is None else body.floor

    confirmed = set()
    epe_used = None
    if body.epe_dataset_id:
        emeta = store.get_meta(body.epe_dataset_id)
        erows = store.get_rows(body.epe_dataset_id)
        if emeta and erows and emeta.source == "EPE":
            for e in normalize_exceptions(erows):
                if e.get("status") in CONFIRMED_STATUSES:
                    confirmed.add(e.get("trade_id"))
            epe_used = emeta.id

    result = backtest(rows, meta.product_type, k=k, floor=floor,
                      confirmed_ids=confirmed, baseline_k=body.baseline_k)
    return {
        "dataset_id": meta.id, "epe_dataset_id": epe_used,
        "product_type": meta.product_type, "metric": metric, "unit": UNIT[metric],
        "k": k, "floor": floor, "has_ground_truth": bool(confirmed), **result,
    }
