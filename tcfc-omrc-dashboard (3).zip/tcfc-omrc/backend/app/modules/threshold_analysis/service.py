"""Threshold Analysis — calibration + backtesting over STORED datasets.

Operates on normalized trade rows (canonical fields from column_map). Metric is
resolved from the dataset's product_type (% / bps / pips). Pure stdlib.
"""
from __future__ import annotations

import statistics
from typing import Dict, List, Optional, Set

from app.core.metrics import deviation, metric_for


def _mad(values: List[float], med: float) -> float:
    abs_dev = [abs(v - med) for v in values]
    return 1.4826 * statistics.median(abs_dev) if abs_dev else 0.0


def _percentile(values: List[float], pct: float) -> float:
    if not values:
        return 0.0
    s = sorted(values)
    idx = min(len(s) - 1, int(round(pct / 100 * (len(s) - 1))))
    return s[idx]


def calibrate(rows: List[Dict], product_type: str, k: float, floor: float) -> List[Dict]:
    metric = metric_for(product_type)
    buckets: Dict[str, Dict] = {}
    for t in rows:
        dev = deviation(metric, t.get("booked"), t.get("reference"), t.get("currency", ""))
        key = t.get("bucket") or product_type
        b = buckets.setdefault(
            key, {"bucket": key, "currency": t.get("currency", ""), "_devs": []}
        )
        b["_devs"].append(dev)

    out: List[Dict] = []
    for b in buckets.values():
        devs = b.pop("_devs")
        if not devs:
            continue
        med = statistics.median(devs)
        mad = _mad(devs, med)
        recommended = max(floor, round(med + k * mad, 4))
        breaches = sum(1 for d in devs if d > recommended)
        out.append(
            {
                **b,
                "sample_size": len(devs),
                "median_dev": round(med, 4),
                "mad": round(mad, 4),
                "recommended_threshold": recommended,
                "p95_dev": round(_percentile(devs, 95), 4),
                "max_dev": round(max(devs), 4),
                "breaches_at_recommended": breaches,
                "breach_rate_pct": round(breaches / len(devs) * 100, 2),
            }
        )
    return sorted(out, key=lambda r: str(r["bucket"]))


def thresholds_map(rows: List[Dict]) -> Dict[str, float]:
    return {r["bucket"]: r["recommended_threshold"] for r in rows}


def backtest(
    trade_rows: List[Dict],
    product_type: str,
    k: float,
    floor: float,
    confirmed_ids: Optional[Set[str]] = None,
    baseline_k: float = 6.0,
) -> Dict:
    """Replay candidate thresholds (k) vs a looser baseline (baseline_k) across
    the dataset's date span, and score precision/recall vs confirmed off-market.
    """
    metric = metric_for(product_type)
    confirmed_ids = confirmed_ids or set()
    candidate = thresholds_map(calibrate(trade_rows, product_type, k, floor))
    baseline = thresholds_map(calibrate(trade_rows, product_type, baseline_k, floor))

    by_date: Dict[str, Dict] = {}
    tp = fp = fn = tn = 0
    cand_total = base_total = 0
    per_bucket: Dict[str, Dict] = {}

    for t in trade_rows:
        bucket = t.get("bucket") or product_type
        dev = deviation(metric, t.get("booked"), t.get("reference"), t.get("currency", ""))
        cthr = candidate.get(bucket, float("inf"))
        bthr = baseline.get(bucket, float("inf"))
        flagged = dev > cthr
        actual = t.get("trade_id") in confirmed_ids

        d = t.get("trade_date") or "n/a"
        row = by_date.setdefault(d, {"date": d, "trades": 0, "candidate_flags": 0, "baseline_flags": 0})
        row["trades"] += 1
        if flagged:
            row["candidate_flags"] += 1; cand_total += 1
        if dev > bthr:
            row["baseline_flags"] += 1; base_total += 1

        pb = per_bucket.setdefault(bucket, {"bucket": bucket, "tp": 0, "fp": 0, "fn": 0, "tn": 0, "n": 0})
        pb["n"] += 1
        if flagged and actual:
            tp += 1; pb["tp"] += 1
        elif flagged and not actual:
            fp += 1; pb["fp"] += 1
        elif not flagged and actual:
            fn += 1; pb["fn"] += 1
        else:
            tn += 1; pb["tn"] += 1

    def _pr(tp_, fp_, fn_):
        p = tp_ / (tp_ + fp_) if (tp_ + fp_) else 0.0
        r = tp_ / (tp_ + fn_) if (tp_ + fn_) else 0.0
        f = 2 * p * r / (p + r) if (p + r) else 0.0
        return round(p, 3), round(r, 3), round(f, 3)

    p, r, f1 = _pr(tp, fp, fn)
    for pb in per_bucket.values():
        pb["precision"], pb["recall"], pb["f1"] = _pr(pb["tp"], pb["fp"], pb["fn"])

    return {
        "series": [by_date[d] for d in sorted(by_date)],
        "accuracy": {"tp": tp, "fp": fp, "fn": fn, "tn": tn,
                     "precision": p, "recall": r, "f1": f1, "confirmed_total": tp + fn},
        "delta": {"candidate_total": cand_total, "baseline_total": base_total,
                  "delta": cand_total - base_total, "baseline_k": baseline_k},
        "per_bucket": sorted(per_bucket.values(), key=lambda x: str(x["bucket"])),
        "candidate_thresholds": candidate,
    }
