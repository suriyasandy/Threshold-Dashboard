"""Threshold Analysis plugin — per-product calibrators, dispatched by product type.

Calibration and backtesting both dispatch on the dataset's product type.
Backtesting uses EPE data (confirmed off-market) as ground truth.
"""
from __future__ import annotations

from typing import Dict, Optional

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel, Field

from app.core import store
from app.core.column_map import CONFIRMED_STATUSES, normalize_exceptions, normalize_trades
from app.core.metrics import UNIT, metric_for
from app.modules.threshold_analysis.calibrators import get_calibrator, list_supported

META = {
    "id": "threshold-analysis",
    "name": "Threshold Analysis",
    "description": "Per-product threshold calibration & backtesting (dispatched by product type).",
    "icon": "sliders",
}

router = APIRouter()


def _trade_dataset(dataset_id: str):
    meta = store.get_meta(dataset_id)
    rows = store.get_rows(dataset_id)
    if meta is None or rows is None:
        raise HTTPException(404, "Dataset not found")
    if meta.source != "BRV_S3":
        raise HTTPException(400, "Threshold Analysis needs a BRV S3 trade dataset")
    return meta, normalize_trades(rows)


def _confirmed_ids(epe_dataset_id: Optional[str]):
    if not epe_dataset_id:
        return set(), None
    emeta = store.get_meta(epe_dataset_id)
    erows = store.get_rows(epe_dataset_id)
    if not emeta or not erows or emeta.source != "EPE":
        return set(), None
    ids = {e.get("trade_id") for e in normalize_exceptions(erows)
           if e.get("status") in CONFIRMED_STATUSES}
    return ids, emeta.id


class CalibrateBody(BaseModel):
    dataset_id: str
    params: Dict = Field(default_factory=dict)


class BacktestBody(BaseModel):
    dataset_id: str
    epe_dataset_id: Optional[str] = None
    params: Dict = Field(default_factory=dict)


@router.get("/trade-datasets")
async def trade_datasets():
    metas = store.list_datasets("BRV_S3")
    return {"datasets": [
        {"id": m.id, "label": m.label, "product_type": m.product_type,
         "metric": metric_for(m.product_type), "unit": UNIT[metric_for(m.product_type)],
         "row_count": m.row_count, "start_date": m.start_date, "end_date": m.end_date,
         "supported": m.product_type in list_supported()}
        for m in metas
    ]}


@router.get("/config")
async def config(product_type: str):
    cal = get_calibrator(product_type)
    cfg = cal.config()
    return {"product_type": product_type, "method": cal.method,
            "method_label": cal.method_label, **cfg}


@router.post("/calibrate")
async def run_calibrate(body: CalibrateBody):
    meta, rows = _trade_dataset(body.dataset_id)
    cal = get_calibrator(meta.product_type)
    result = cal.calibrate(meta.product_type, rows, body.params)
    return {"dataset_id": meta.id, "product_type": meta.product_type, **result}


@router.post("/backtest")
async def run_backtest(body: BacktestBody):
    meta, rows = _trade_dataset(body.dataset_id)
    cal = get_calibrator(meta.product_type)
    confirmed, epe_used = _confirmed_ids(body.epe_dataset_id)
    result = cal.backtest(meta.product_type, rows, confirmed, body.params)
    return {"dataset_id": meta.id, "epe_dataset_id": epe_used,
            "product_type": meta.product_type, **result}
