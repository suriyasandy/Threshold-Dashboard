import { useState, useCallback, useEffect } from "react";
import {
  BarChart, Bar, LineChart, Line, XAxis, YAxis, Tooltip, Legend,
  ResponsiveContainer, Cell, CartesianGrid,
} from "recharts";
import { api } from "../../api/client.js";
import { useAsync } from "../../lib/useAsync.js";
import { ModuleHeader, Card, Stat, Loader, ErrorState, StatusBadge } from "../../components/ui.jsx";
import DataTable from "../../components/DataTable.jsx";
import DatasetSelector from "../../components/DatasetSelector.jsx";

export const meta = {
  id: "threshold-analysis",
  title: "Threshold Analysis",
  description: "Per-check calibration with OR/AND/combination logic.",
  icon: "sliders",
  path: "/threshold-analysis",
  order: 2,
};

const STATUS_COLOR = { pass: "#1F8A4C", watch: "#C9821A", breach: "#C0392B" };
const alertStatus = (r) => (r >= 10 ? "breach" : r >= 4 ? "watch" : "pass");

function fmtCheck(v, unit) {
  if (v == null) return "—";
  if (unit === "ccy") return Number(v).toLocaleString(undefined, { maximumFractionDigits: 0 });
  if (unit === "%") return `${Number(v).toFixed(3)}%`;
  return `${Number(v).toFixed(2)} ${unit}`;
}

export default function ThresholdAnalysis() {
  const cfg = useAsync(useCallback(() => api.module("threshold-analysis", "/config"), []), []);
  const tds = useAsync(useCallback(() => api.module("threshold-analysis", "/trade-datasets"), []), []);
  const eds = useAsync(useCallback(() => api.module("data-fetch", "/datasets", { source: "EPE" }), []), []);

  const [datasetId, setDatasetId] = useState("");
  const [tab, setTab] = useState("calibration");
  const datasets = tds.data?.datasets || [];
  const selected = datasets.find((d) => d.id === datasetId);
  useEffect(() => { if (datasets.length && !datasetId) setDatasetId(datasets[0].id); }, [datasets, datasetId]);

  if (cfg.loading || tds.loading) return <><Header /><Loader label="Loading…" /></>;
  if (cfg.error) return <><Header /><ErrorState error={cfg.error} /></>;

  return (
    <>
      <Header />
      {tds.error && <ErrorState error={tds.error} />}
      <div className="toolbar">
        <DatasetSelector label="Trade dataset (BRV S3)" datasets={datasets} value={datasetId}
          onChange={setDatasetId} emptyHint="Pull a BRV S3 trade dataset in Data Fetch first." />
        {selected && (
          <div className="tabs">
            <button className={`tab ${tab === "calibration" ? "active" : ""}`} onClick={() => setTab("calibration")}>Calibration</button>
            <button className={`tab ${tab === "backtest" ? "active" : ""}`} onClick={() => setTab("backtest")}>Backtesting</button>
          </div>
        )}
      </div>
      {selected && tab === "calibration" && <Calibration ds={selected} cfg={cfg.data} />}
      {selected && tab === "backtest" && <Backtest ds={selected} cfg={cfg.data} epeDatasets={eds.data?.datasets || []} />}
    </>
  );
}

const Header = () => (
  <ModuleHeader title="Threshold Analysis"
    description="Each check (Price, PnL, PnL/Notional) calibrated from its own distribution by percentile or MAD, then combined via OR / AND / Combination — per the OMRC methodology." />
);

function Controls({ method, setMethod, percentile, setPercentile, k, setK, logic, setLogic, cfg, onRun }) {
  return (
    <Card title="Calibration parameters">
      <div className="controls controls--row">
        <label className="control"><span>Method</span>
          <select value={method} onChange={(e) => setMethod(e.target.value)}>
            {cfg.methods.map((m) => <option key={m.id} value={m.id}>{m.label}</option>)}
          </select>
        </label>
        {method === "percentile" ? (
          <label className="control"><span>Percentile: <strong className="mono">{percentile.toFixed(1)}</strong></span>
            <input type="range" min="80" max="99.9" step="0.1" value={percentile} onChange={(e) => setPercentile(Number(e.target.value))} /></label>
        ) : (
          <label className="control"><span>MAD multiplier k: <strong className="mono">{k.toFixed(1)}</strong></span>
            <input type="range" min="1" max="8" step="0.5" value={k} onChange={(e) => setK(Number(e.target.value))} /></label>
        )}
        <label className="control" style={{ minWidth: 280 }}><span>Combination logic</span>
          <select value={logic} onChange={(e) => setLogic(e.target.value)}>
            {cfg.logics.map((l) => <option key={l.id} value={l.id}>{l.label}</option>)}
          </select>
        </label>
        <button className="btn" onClick={onRun}>Refresh</button>
      </div>
    </Card>
  );
}

function checkColumns(checks, cfg) {
  const labelOf = (id) => cfg.checks.find((c) => c.id === id)?.label || id;
  const base = [
    { key: "bucket", label: "Bucket", mono: true },
    { key: "n", label: "n", align: "right", mono: true },
  ];
  const checkCols = checks.map((c) => ({
    key: c, label: labelOf(c), align: "right", mono: true,
    render: (_, row) => fmtCheck(row.checks[c]?.threshold, row.checks[c]?.unit),
  }));
  const tail = [{
    key: "alert_rate_pct", label: "Alert rate", align: "right", mono: true,
    render: (v) => <span className="cell-status">{Number(v).toFixed(1)}% <StatusBadge status={alertStatus(v)} /></span>,
  }];
  return [...base, ...checkCols, ...tail];
}

function Calibration({ ds, cfg }) {
  const [method, setMethod] = useState("percentile");
  const [percentile, setPercentile] = useState(95);
  const [k, setK] = useState(4);
  const [logic, setLogic] = useState("COMBO");

  const load = useCallback(
    () => api.module("threshold-analysis", "/calibrate", undefined, {
      method: "POST",
      body: JSON.stringify({ dataset_id: ds.id, method, percentile, k, logic, checks: cfg.checks.map((c) => c.id) }),
    }),
    [ds.id, method, percentile, k, logic]
  );
  const { loading, data, error, reload } = useAsync(load, [ds.id, method, percentile, k, logic]);
  const buckets = data?.buckets || [];
  const chartData = buckets.map((b) => ({ name: String(b.bucket), value: b.alert_rate_pct, status: alertStatus(b.alert_rate_pct) }));

  return (
    <>
      <Controls {...{ method, setMethod, percentile, setPercentile, k, setK, logic, setLogic, cfg }} onRun={reload} />
      {loading && <Loader />}
      {error && <ErrorState error={error} />}
      {data && (
        <>
          <Card title={`Alert rate by bucket — ${data.trade_count} trades · ${data.logic} logic`}>
            <div style={{ width: "100%", height: 230 }}>
              <ResponsiveContainer>
                <BarChart data={chartData} margin={{ top: 8, right: 8, bottom: 8, left: 8 }}>
                  <XAxis dataKey="name" tick={{ fontSize: 11 }} /><YAxis tick={{ fontSize: 11 }} unit="%" />
                  <Tooltip formatter={(v) => [`${v}%`, "Alert rate"]} contentStyle={{ fontSize: 12 }} />
                  <Bar dataKey="value" radius={[3, 3, 0, 0]}>{chartData.map((d, i) => <Cell key={i} fill={STATUS_COLOR[d.status]} />)}</Bar>
                </BarChart>
              </ResponsiveContainer>
            </div>
          </Card>
          <Card title="Per-check thresholds">
            <DataTable columns={checkColumns(data.checks, cfg)} rows={buckets} rowKey="bucket" />
          </Card>
        </>
      )}
    </>
  );
}

function Backtest({ ds, cfg, epeDatasets }) {
  const [method, setMethod] = useState("percentile");
  const [percentile, setPercentile] = useState(95);
  const [k, setK] = useState(4);
  const [logic, setLogic] = useState("COMBO");
  const [epeId, setEpeId] = useState("");

  const load = useCallback(
    () => api.module("threshold-analysis", "/backtest", undefined, {
      method: "POST",
      body: JSON.stringify({ dataset_id: ds.id, method, percentile, k, logic, epe_dataset_id: epeId || null, checks: cfg.checks.map((c) => c.id) }),
    }),
    [ds.id, method, percentile, k, logic, epeId]
  );
  const { loading, data, error, reload } = useAsync(load, [ds.id, method, percentile, k, logic, epeId]);

  return (
    <>
      <Controls {...{ method, setMethod, percentile, setPercentile, k, setK, logic, setLogic, cfg }} onRun={reload} />
      <Card title="Ground truth">
        <div className="controls controls--row">
          <label className="control" style={{ minWidth: 280 }}><span>EPE dataset (confirmed off-market)</span>
            <select value={epeId} onChange={(e) => setEpeId(e.target.value)}>
              <option value="">None (alert volume only)</option>
              {epeDatasets.map((d) => <option key={d.id} value={d.id}>{d.label}</option>)}
            </select>
          </label>
          <button className="btn" onClick={reload}>Re-run</button>
        </div>
      </Card>
      {loading && <Loader label="Replaying…" />}
      {error && <ErrorState error={error} />}
      {data && <BacktestResults data={data} />}
    </>
  );
}

function BacktestResults({ data }) {
  const a = data.accuracy, d = data.delta;
  const dCls = d.delta > 0 ? "delta-pos" : d.delta < 0 ? "delta-neg" : "";
  const dSign = d.delta > 0 ? "+" : "";
  const cols = [
    { key: "bucket", label: "Bucket", mono: true },
    { key: "n", label: "n", align: "right", mono: true },
    { key: "tp", label: "TP", align: "right", mono: true },
    { key: "fp", label: "FP", align: "right", mono: true },
    { key: "fn", label: "FN", align: "right", mono: true },
    { key: "precision", label: "Precision", align: "right", mono: true, render: (v) => v.toFixed(2) },
    { key: "recall", label: "Recall", align: "right", mono: true, render: (v) => v.toFixed(2) },
    { key: "f1", label: "F1", align: "right", mono: true, render: (v) => v.toFixed(2) },
  ];
  return (
    <>
      <div className="stat-grid">
        <Stat label="Candidate alerts" value={d.candidate_total} sub="vs looser baseline" />
        <Stat label="Baseline alerts" value={d.baseline_total} />
        <Stat label="Delta" value={<span className={dCls}>{dSign}{d.delta}</span>} sub={d.delta < 0 ? "fewer" : d.delta > 0 ? "more" : "no change"} />
        <Stat label="Confirmed off-market" value={a.confirmed_total} sub={data.has_ground_truth ? "from EPE" : "no EPE selected"} />
      </div>
      <Card title={`Alert volume over time — ${data.logic} logic`}>
        <div style={{ width: "100%", height: 250 }}>
          <ResponsiveContainer>
            <LineChart data={data.series} margin={{ top: 8, right: 12, bottom: 8, left: 0 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="#eef1f4" />
              <XAxis dataKey="date" tick={{ fontSize: 10 }} /><YAxis tick={{ fontSize: 11 }} allowDecimals={false} />
              <Tooltip contentStyle={{ fontSize: 12 }} /><Legend wrapperStyle={{ fontSize: 12 }} />
              <Line type="monotone" dataKey="candidate_flags" name="Candidate" stroke="#0E7C7B" strokeWidth={2} dot={false} />
              <Line type="monotone" dataKey="baseline_flags" name="Baseline" stroke="#C9821A" strokeWidth={2} strokeDasharray="5 4" dot={false} />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </Card>
      {data.has_ground_truth ? (
        <>
          <div className="stat-grid">
            <Stat label="Precision" value={a.precision.toFixed(2)} status={a.precision >= 0.8 ? "pass" : a.precision >= 0.5 ? "watch" : "breach"} />
            <Stat label="Recall (vs confirmed)" value={a.recall.toFixed(2)} status={a.recall >= 0.8 ? "pass" : a.recall >= 0.5 ? "watch" : "breach"} />
            <Stat label="F1" value={a.f1.toFixed(2)} />
            <Stat label="Missed (FN)" value={a.fn} status={a.fn === 0 ? "pass" : "breach"} />
          </div>
          <Card title="Confusion — candidate vs confirmed off-market">
            <div className="confusion">
              <div className="cm-cell cm-tp"><span className="mono">{a.tp}</span><small>True positive</small></div>
              <div className="cm-cell cm-fp"><span className="mono">{a.fp}</span><small>False positive</small></div>
              <div className="cm-cell cm-fn"><span className="mono">{a.fn}</span><small>False negative</small></div>
              <div className="cm-cell cm-tn"><span className="mono">{a.tn}</span><small>True negative</small></div>
            </div>
          </Card>
        </>
      ) : (
        <Card><div className="empty"><div className="empty-title">Select an EPE dataset to score precision / recall.</div>
          <div className="empty-hint">Recall is vs confirmed off-market only — historic passes aren't labelled (the known methodology limitation).</div></div></Card>
      )}
      <Card title="Per-bucket accuracy"><DataTable columns={cols} rows={data.per_bucket} rowKey="bucket" /></Card>
    </>
  );
}
