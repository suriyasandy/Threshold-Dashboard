"""Threshold Analysis plugin — methodology-faithful, dataset-driven.

Per-check calibration (Price / PnL / PnL-Notional) by percentile or MAD, combined
via OR / AND / COMBINATION logic. Runs on datasets pulled in Data Fetch.
"""
from __future__ import annotations

from typing import Dict, List, Optional

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel, Field

from app.core import store
from app.core.column_map import CONFIRMED_STATUSES, normalize_exceptions, normalize_trades
from app.core.metrics import UNIT, metric_for
from app.modules.threshold_analysis.service import (
    CHECK_LABEL,
    DEFAULT_CHECKS,
    backtest_checks,
    calibrate_checks,
)

META = {
    "id": "threshold-analysis",
    "name": "Threshold Analysis",
    "description": "Per-check calibration (percentile / MAD) with OR-AND-combination logic on a fetched dataset.",
    "icon": "sliders",
}

router = APIRouter()

LOGICS = ["OR", "AND", "COMBO"]


def _trade_dataset(dataset_id: str):
    meta = store.get_meta(dataset_id)
    rows = store.get_rows(dataset_id)
    if meta is None or rows is None:
        raise HTTPException(404, "Dataset not found")
    if meta.source != "BRV_S3":
        raise HTTPException(400, "Threshold Analysis needs a BRV S3 trade dataset")
    return meta, normalize_trades(rows)


def _params(method: str, percentile: float, k: float, checks: List[str]) -> Dict[str, dict]:
    if method == "percentile":
        return {c: {"percentile": percentile} for c in checks}
    return {c: {"k": k, "floor": 0.0} for c in checks}


class CalibrateBody(BaseModel):
    dataset_id: str
    method: str = "percentile"          # percentile | mad
    percentile: float = 95.0
    k: float = 4.0
    logic: str = "COMBO"                 # OR | AND | COMBO
    checks: List[str] = Field(default_factory=lambda: list(DEFAULT_CHECKS))


class BacktestBody(CalibrateBody):
    epe_dataset_id: Optional[str] = None
    baseline_percentile: float = 99.0    # looser reference
    baseline_k: float = 6.0


@router.get("/config")
async def config():
    return {
        "checks": [{"id": c, "label": CHECK_LABEL[c]} for c in DEFAULT_CHECKS],
        "logics": [
            {"id": "OR", "label": "OR — any check alerts"},
            {"id": "AND", "label": "AND — all checks alert"},
            {"id": "COMBO", "label": "Combination — Price OR (PnL AND PnL/Notional)"},
        ],
        "methods": [
            {"id": "percentile", "label": "Percentile of distribution"},
            {"id": "mad", "label": "Median + k·MAD"},
        ],
    }


@router.get("/trade-datasets")
async def trade_datasets():
    metas = store.list_datasets("BRV_S3")
    return {"datasets": [
        {"id": m.id, "label": m.label, "product_type": m.product_type,
         "metric": metric_for(m.product_type), "unit": UNIT[metric_for(m.product_type)],
         "row_count": m.row_count, "start_date": m.start_date, "end_date": m.end_date}
        for m in metas
    ]}


@router.post("/calibrate")
async def run_calibrate(body: CalibrateBody):
    meta, rows = _trade_dataset(body.dataset_id)
    if body.logic not in LOGICS:
        raise HTTPException(400, "logic must be OR | AND | COMBO")
    params = _params(body.method, body.percentile, body.k, body.checks)
    buckets = calibrate_checks(rows, meta.product_type, body.checks, body.method, params, body.logic)
    return {
        "dataset_id": meta.id, "product_type": meta.product_type,
        "metric": metric_for(meta.product_type), "method": body.method,
        "percentile": body.percentile, "k": body.k, "logic": body.logic,
        "checks": body.checks, "trade_count": len(rows), "buckets": buckets,
    }


@router.post("/backtest")
async def run_backtest(body: BacktestBody):
    meta, rows = _trade_dataset(body.dataset_id)
    if body.logic not in LOGICS:
        raise HTTPException(400, "logic must be OR | AND | COMBO")
    params = _params(body.method, body.percentile, body.k, body.checks)
    baseline = _params(body.method, body.baseline_percentile, body.baseline_k, body.checks)

    confirmed, epe_used = set(), None
    if body.epe_dataset_id:
        emeta = store.get_meta(body.epe_dataset_id)
        erows = store.get_rows(body.epe_dataset_id)
        if emeta and erows and emeta.source == "EPE":
            for e in normalize_exceptions(erows):
                if e.get("status") in CONFIRMED_STATUSES:
                    confirmed.add(e.get("trade_id"))
            epe_used = emeta.id

    result = backtest_checks(rows, meta.product_type, body.checks, body.method,
                             params, body.logic, confirmed_ids=confirmed, baseline_params=baseline)
    return {
        "dataset_id": meta.id, "epe_dataset_id": epe_used, "product_type": meta.product_type,
        "method": body.method, "logic": body.logic, "checks": body.checks,
        "has_ground_truth": bool(confirmed), **result,
    }
